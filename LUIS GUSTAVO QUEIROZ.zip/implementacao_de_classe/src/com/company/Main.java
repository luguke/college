package com.company;

public class Main {

    public static void main(String[] args) {
        Pessoa luis =  new Pessoa();
        Pessoa giba =  new Pessoa();
        Pessoa andre =  new Pessoa();

    }
}