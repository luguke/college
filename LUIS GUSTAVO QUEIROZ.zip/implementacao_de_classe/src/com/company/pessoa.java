package com.company;

import java.util.Date;

class Pessoa {
    private String nome;
    private Date datanascimento;
    private char genero;
    private int altura;
    private String cpf;
    private String rg;
    private String etnia;
    private String nacionalidade;
    private String cidadeNatal;

}
